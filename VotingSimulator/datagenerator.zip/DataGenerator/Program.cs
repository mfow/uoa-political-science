﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace DataGenerator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Voting Simulator Data Generator");
            Console.WriteLine();

            Stream strm;

            while (true)
            {
                Console.Write("Output Filename:");
                string filename = Console.ReadLine();

                try
                {
                    strm = new FileStream(filename, FileMode.OpenOrCreate, FileAccess.ReadWrite);
                }
                catch (Exception)
                {
                    Console.WriteLine("Error.");
                    continue;
                }

                if (strm.Length != 0)
                {
                    Console.Write("File is not empty. Overwrite? (y/n)");

                    if (Console.ReadLine().ToLower().StartsWith("y"))
                    {
                        strm.SetLength(0);
                        break;
                    }
                }
                else
                {
                    break;
                }
            }

            var w = new StreamWriter(strm);

            Console.Write("Method:");
            string method = Console.ReadLine();

            w.WriteLine("Voting Preferences,");
            w.WriteLine("Version,Method,");
            w.Write("1000,");
            w.Write(method);
            w.WriteLine(",");

            List<Tuple<string, string>> metadata = new List<Tuple<string, string>>();

            Console.Write("Title:");
            metadata.Add(new Tuple<string, string>("Name", Console.ReadLine()));

            Console.Write("Year:");
            metadata.Add(new Tuple<string, string>("Year", Console.ReadLine()));

            Console.Write("Author:");
            metadata.Add(new Tuple<string, string>("Author", Console.ReadLine()));

            metadata.Add(new Tuple<string, string>("Date Created", DateTime.Now.ToLongDateString()));
            metadata.Add(new Tuple<string, string>("Time Created", DateTime.Now.ToLongTimeString()));

            WriteCSVData(w, metadata);

            switch (method.ToLower())
            {
                case "fpp":
                    FPP(w);
                    break;
                default:
                    Console.WriteLine("Unknown method.");
                    break;
            }

            w.Flush();
            w.Close();
        }

        static void FPP(StreamWriter w)
        {
            int electorateCount = ReadInt("Number of electorates");

            List<string> parties = new List<string>();

            List<List<List<Tuple<string, string>>>> electorates = new List<List<List<Tuple<string, string>>>>();

            for (int i = 0; i < electorateCount; i++)
            {
                List<List<Tuple<string, string>>> candidates = new List<List<Tuple<string, string>>>();

                Console.WriteLine("Electorate " + (i + 1).ToString());

                int candidateCount = ReadInt("Number of candidates");

                for (int j = 0; j < candidateCount; j++)
                {
                    List<Tuple<string, string>> candidate = new List<Tuple<string, string>>();

                    Console.Write("Candidate Name:");
                    string name = Console.ReadLine();

                    Console.Write("Party:");
                    string party = Console.ReadLine();

                    var votes = ReadInt("Number of Votes");

                    candidate.Add(new Tuple<string, string>("Name", name));
                    candidate.Add(new Tuple<string, string>("Party", party));
                    candidate.Add(new Tuple<string, string>("Votes", votes.ToString()));

                    int partyIndex;

                    if (party == string.Empty)
                    {
                        partyIndex = -1;
                    }
                    else
                    {
                        if (parties.Contains(party))
                        {
                            partyIndex = parties.IndexOf(party);
                        }
                        else
                        {
                            parties.Add(party);
                            partyIndex = parties.Count - 1;
                        }
                    }

                    candidates.Add(candidate);
                }

                electorates.Add(candidates);
            }

            w.WriteLine(parties.Count + ",");
            w.WriteLine("Name,");

            foreach (var partyName in parties)
            {
                w.WriteLine(partyName + ",");
            }

            w.WriteLine(electorateCount + ",");

            for (int i = 0; i < electorateCount; i++)
            {
                var candidates = electorates[i];

                w.WriteLine(candidates.Count + ",");

                WriteCSVData(w, candidates);

                var numberOfVotes = (from x in candidates select int.Parse(GetValueFromTupleList("Votes", x, "0"))).ToList();

                w.WriteLine(numberOfVotes.Count + ",");

                List<int> votes = new List<int>();

                for (int j = 0; j < numberOfVotes.Count; j++)
                {
                    for (int k = 0; k < numberOfVotes[j]; k++)
                    {
                        votes.Add(j);
                    }
                }

                var r = new Random();

                votes = (from x in votes let y = r.NextDouble() orderby y select x).ToList();

                foreach (var vote in votes)
                {
                    w.WriteLine(vote.ToString() + ",");
                }

                w.Flush();
            }
        }

        static int ReadInt(string name)
        {
            while (true)
            {
                Console.Write(name + ":");

                try
                {
                    return int.Parse(Console.ReadLine());
                }
                catch (Exception)
                {
                    continue;
                }
            }
        }

        static void WriteCSVData(StreamWriter w, IEnumerable<Tuple<string, string>> data)
        {
            WriteCSVData(w, (from x in data select x.Item1));
            WriteCSVData(w, (from x in data select x.Item2));
        }

        static string GetValueFromTupleList(string key, IEnumerable<Tuple<string, string>> tuples, string defaultValue)
        {
            foreach (var item in tuples)
            {
                if (item.Item1 == key)
                {
                    return item.Item2;                    
                }
            }

            return defaultValue;
        }

        static void WriteCSVData(StreamWriter w, IEnumerable<IEnumerable<Tuple<string, string>>> data)
        {
            List<string> keys = new List<string>();

            foreach (var item in data)
            {
                keys.AddRange(from x in item select x.Item1);
            }

            keys = keys.Distinct().ToList();

            WriteCSVData(w, from k in keys select new Tuple<string, List<string>>(k, (from r in data select GetValueFromTupleList(k, r, string.Empty)).ToList()));
        }

        static void WriteCSVData(StreamWriter w, IEnumerable<Tuple<string, List<string>>> data)
        {
            int numberOfElements = (from x in data select x.Item2.Count).Max();

            foreach (var x in data)
            {
                if (x.Item2.Count != numberOfElements)
                {
                    throw new ArgumentException();
                }
            }

            WriteCSVData(w, from x in data select x.Item1);

            for (int i = 0; i < numberOfElements; i++)
            {
                WriteCSVData(w, from x in data select x.Item2[i]);
            }
        }

        static void WriteCSVData(StreamWriter w, IEnumerable<string> data)
        {
            foreach (var s in data)
            {
                w.Write(s);
                w.Write(',');
            }

            w.WriteLine();
            w.Flush();
        }
    }
}
